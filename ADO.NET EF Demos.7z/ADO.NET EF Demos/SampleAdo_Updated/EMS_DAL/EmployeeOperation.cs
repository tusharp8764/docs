﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using EMSEntity;
namespace EMS_DAL
{
    public class EmployeeOperation
    {
        static string empConnStr = ConfigurationManager.ConnectionStrings["conStr"].ToString();
        static SqlConnection empConnObj;
        SqlCommand empCommand;
        DataTable dtDept, dtEmp;
        SqlDataReader empReader = null;
        public EmployeeOperation()
        {
            empConnObj = new SqlConnection();
            empConnObj.ConnectionString = empConnStr;
        }
        // Load ComboBox
        //Insert Data
        // Display Data
        // Get Next Id - using O/P parameter

        public DataTable LoadDeparment()
        {

            try
            {
                dtDept = new DataTable();
                empCommand = new SqlCommand("Geetha.usp_GetDepartment", empConnObj);
                empCommand.CommandType = CommandType.StoredProcedure;
                empConnObj.Open();
                empReader = empCommand.ExecuteReader();
                dtDept.Load(empReader);

            }
            catch (SqlException)
            {
                throw;

            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                empReader.Close();
                if (empConnObj.State == ConnectionState.Open) empConnObj.Close();
            }
            return dtDept;
        }

        public int AddEmployee_DAL(Employee emp)
        {
            int rowsAffected = 0;
            try
            {
                empCommand = new SqlCommand("Geetha.usp_AddEmployee", empConnObj);
                empCommand.CommandType = CommandType.StoredProcedure;//,@eLoc,@ePh,@eDeptId
                empCommand.Parameters.AddWithValue("@eName", emp.EmployeeName);
                empCommand.Parameters.AddWithValue("@eLoc", emp.Location);
                empCommand.Parameters.AddWithValue("@ePh", emp.PhoneNo);
                empCommand.Parameters.AddWithValue("@eDeptId", emp.Department);
                empConnObj.Open();
                rowsAffected = empCommand.ExecuteNonQuery();

            }
            catch (SqlException)
            {

                throw;
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                if (empConnObj.State == ConnectionState.Open) empConnObj.Close();
            }
            return rowsAffected;

        }

        public DataTable GetEmployee_DAL()
        {
            try
            {
                dtEmp = new DataTable();
                empCommand = new SqlCommand("Geetha.usp_DisplayEmployee", empConnObj);
                empCommand.CommandType = CommandType.StoredProcedure;
                empConnObj.Open();
                empReader = empCommand.ExecuteReader();
                if (empReader.HasRows)
                {
                    dtEmp.Load(empReader);
                }
            }
            catch (SqlException ex)
            {

                throw;
            }
            catch (Exception ex)
            {

                throw;
            }
            finally
            {
                empReader.Close();
                if (empConnObj.State == ConnectionState.Open) empConnObj.Close();
            }
            return dtEmp;
        }

    }
}
